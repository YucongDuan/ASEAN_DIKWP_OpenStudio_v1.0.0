# Contribution

Student authors: [add names with consent]

Research foundations: Yucong Duan (段玉聪), DIKWP and the selected repositories.

Inherited components:


My changes:
添加单位对齐与币种检查

Hypothesis and counterexample:


No publication, repository creation or upstream pull request is performed automatically.
