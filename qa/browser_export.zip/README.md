# 中越跨境商品语义核验

Created in DIKWP OpenStudio · Research methods: Yucong Duan (段玉聪)

## problem
比较中文和越南语商品资料中的重量、币种、实体与交易目的，发现误解并保留证据。

## beneficiary
—

## purpose
比较中文和越南语商品资料中的重量、币种、实体与交易目的，发现误解并保留证据。

## data
—

## information
—

## knowledge
—

## wisdom
—

## constraints
—

## inherited
—

## changed
添加单位对齐与币种检查

## hypothesis
—

## evidence
—

## reflection
—

## Upstream selection
- DIKWP-MESH- — https://github.com/YucongDuan/DIKWP-MESH- — commit to be pinned — Apache-2.0
- DIKWP-PACT-v0.1.0 — https://github.com/YucongDuan/DIKWP-PACT-v0.1.0 — commit to be pinned — Apache-2.0
- DIKWP-VERITYWEAVE-v2.0.0 — https://github.com/YucongDuan/DIKWP-VERITYWEAVE-v2.0.0 — commit to be pinned — Apache-2.0

## Experiment records
- alignment · 2026-09-16T08:26:52.784Z
- three-no · 2026-09-16T08:26:52.882Z
- action · 2026-09-16T08:26:52.949Z
- purpose · 2026-09-16T08:26:53.032Z

This is a learning contribution, not a certificate or proof of originality.

## Run the new teaching scaffold

`python experiment.py`

`python -m unittest discover -s tests -v`

The included code is a new, deliberately small semantic-slot experiment, not copied upstream code. Pin and inspect upstream projects before writing your adapter.
